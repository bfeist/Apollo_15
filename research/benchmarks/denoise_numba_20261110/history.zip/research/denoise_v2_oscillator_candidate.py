"""Separate strict complex-exp candidate; never modifies the qualified backend."""
import importlib.util
from pathlib import Path
import sys

import numba
import numpy as np
from denoise_v2_numba import fused_observations


@numba.njit(cache=True, fastmath=False, parallel=False)
def complex_exp(value):
    result = np.empty(value.shape, dtype=np.complex128)
    for i in range(value.size):
        result.flat[i] = np.exp(value.flat[i])
    return result


class _NumpyWithExp:
    """Override only the candidate module's complex-array exponential calls."""
    def __getattr__(self, name):
        return getattr(np, name)

    def exp(self, value):
        if isinstance(value, np.ndarray) and value.dtype == np.complex128:
            return complex_exp(value)
        return np.exp(value)


_name = '_apollo15_denoise_v2_oscillator_candidate_reference'
_spec = importlib.util.spec_from_file_location(_name, Path(__file__).resolve().parents[1]/'scripts/denoise_v2.py')
_reference = importlib.util.module_from_spec(_spec)
sys.modules[_name] = _reference
_spec.loader.exec_module(_reference)
_reference.observations = fused_observations
_reference.np = _NumpyWithExp()
model_window = _reference.model_window
corrected_chunks = _reference.corrected_chunks


def warmup():
    complex_exp(np.zeros(8, dtype=np.complex128))
    complex_exp(np.zeros((2, 4), dtype=np.complex128))
