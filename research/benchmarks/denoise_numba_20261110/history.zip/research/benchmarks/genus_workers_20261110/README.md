# Genus denoise concurrency profiling — November 10, 2026

Best measured configuration: six workers restricted to logical CPUs
`0,2,4,8,10,12` (three physical cores from each L3 cache group). This reached
25.49 model-equivalent audio hours per elapsed hour. Eight balanced workers
were close at 24.74; treat six to eight as the useful range, not a precisely
established global optimum. With the current unmodified launcher, twelve
workers were fastest tested (22.68 and 23.27 in two runs). Merely setting six
workers without affinity produced 22.10, not 25.49.

## Measurements

| Workers | Default scheduling, audio h/h | Balanced affinity, audio h/h |
|---|---:|---:|
| 1 | 8.80 | — |
| 2 | 14.61 | — |
| 4 | 21.37 | 23.57 |
| 6 | 22.10 | 25.49 |
| 8 | 21.29 | 24.74 |
| 12 | 22.68; 23.27 | — |
| 16 | 22.40 | — |
| 24 | 21.87 | — |
| 32 | 21.23 | — |

Affinity masks: four = `0,2,8,10`; six = `0,2,4,8,10,12`;
eight = `0,2,4,6,8,10,12,14`. All benchmark children inherit the mask;
individual processes are not pinned to a specific core.

## Method and limits

`research/profile_genus_workers.py` starts fresh processes, loads the same
136-second original CH03 interval from A15_T510077 (2048–2184 seconds) and
saved v1 hints, then releases a synchronized start barrier. Each child runs the
unchanged production `model_window(..., defer_compact=True)` two times in the
initial sweep and three times in confirmation/affinity trials. Numerical
libraries have one thread per process. Inputs and outputs are hashed; every
child within each trial must match. Raw measurements are saved alongside this
file, including per-iteration time, CPU time, hashes, and peak temperatures.

Timing excludes source/hint loading, process startup and output hashing. All
timed audio work is in RAM. Throughput counts 64 seconds per model, matching
the production steady-state anchor spacing; it does not count the overlapping
136-second context as fresh audio. Batch wall time uses the last finisher.
Production blending, compact union application, writes, checkpoints, and
publication are excluded. This is a scaling benchmark on one real, complex
interval, not a full archive throughput prediction. No production workers ran
during these trials, and no production checkpoints/audio/configuration changed.

## Thermal, network, and system findings

- CPU: Ryzen 9 5900XT, 16 cores/32 threads, 64 MiB L3 across two groups.
  Group masks are `0-7,16-23` and `8-15,24-31`.
- Highest sampled CPU control temperature across the default sweep and
  confirmation was 80.25 C; highest CCD reading was 82 C. Balanced six peaked
  at 76 C control temperature. AMD specifies 90 C Tjmax. No evidence of hitting
  that limit; normal boost/power management effects were not isolated.
- Sampled frequency reports remained around 4.5 GHz under heavy load,
  including 4.45–4.53 GHz with 32 workers. These are sysfs samples, not
  hardware-counter effective-frequency measurements.
- No swapping or material I/O wait observed. Network cannot explain the timed
  in-memory scaling plateau.
- Ubuntu 26.04.1, kernel 7.0.0-43-generic; `amd-pstate-epp` active,
  `powersave` governor with `balance_performance` EPP; boost enabled.
  Configured maximum frequency equals reported maximum (4,981,510 kHz).
- `amd64-microcode` 3.20251202.1ubuntu2 and `linux-firmware`
  20260319.git217ca6e4.1ubuntu are installed; CPU microcode 0x0a201213.
  MSI MEG X570 ACE BIOS 1.S3, dated 2026-08-18. These facts establish presence,
  not that every package/firmware revision is the newest available.
- RAM speed/channel configuration was not accessible without privileged DMI
  access. Hardware performance counters were restricted (`perf_event_paranoid=4`).
  Thus memory bandwidth saturation is a plausible contributor, not a directly
  measured exclusive cause. The affinity experiments demonstrate sensitivity
  to CPU placement/cache topology.

## Reproduction

On Genus, through its qualified environment:

```sh
/home/bfeist/.local/bin/uv run --no-project --python /home/bfeist/.local/share/apollo15-venv/bin/python /mnt/f/_repos/Apollo_15/research/profile_genus_workers.py --output /home/bfeist/new-sweep.json
taskset -c 0,2,4,8,10,12 /home/bfeist/.local/bin/uv run --no-project --python /home/bfeist/.local/share/apollo15-venv/bin/python /mnt/f/_repos/Apollo_15/research/profile_genus_workers.py --counts 6 --repeats 3 --output /home/bfeist/new-affinity.json
```

Do not run benchmarks alongside production when comparing throughput.
The production launcher currently does not apply this affinity mask; that
would require a separate launcher integration respecting its frozen identity.

References: [AMD 5900XT specifications](https://www.amd.com/en/products/processors/desktops/ryzen/5000-series/amd-ryzen-9-5900xt.html),
[Linux AMD P-State documentation](https://www.kernel.org/doc/html/v6.11/admin-guide/pm/amd-pstate.html),
[AMD Windows chipset package](https://www.amd.com/en/resources/support-articles/release-notes/RN-RYZEN-CHIPSET-7-06-02-123.html).
