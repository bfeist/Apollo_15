# Denoise acceleration investigation — November 10, 2026

The initial investigation favored small fused Numba kernels over porting the
whole denoiser to Rust/C. The first isolated kernel improved measured Genus
six-worker model throughput by 38%, with identical outputs on the tested
interval. The later production backend and broader qualification are described
at the end of this report.

## Measurements

| Test | Original | Fused observations | Throughput ratio |
|---|---:|---:|---:|
| Windows single-worker model, mean of two | 9.548 s | 7.647 s | 1.25x |
| Genus single-worker model, mean of two | 7.289 s | 6.530 s | 1.12x |
| Genus six workers, 3 models each, batch wall time | 44.962 s | 32.547 s | 1.38x |
| Genus six workers, model-equivalent audio h/h | 25.62 | 35.40 | 1.38x |

Six-worker tests used the same balanced affinity `0,2,4,8,10,12`. Timing starts
after all workers load their inputs and precompile a representative kernel
signature. The single-worker test order is original/Numba/Numba/original.
Compilation of any additional array-layout signatures may affect the first
optimized model call. The six-worker tests ran baseline then optimized, with
three model iterations per worker; no statistical confidence interval is claimed.

The subagent also measured a synthetic production-sized projection kernel on
Windows: seven warm iterations, median 14.72 ms original vs 2.54 ms Numba
(5.8x). This kernel-only result is not an overall pipeline speedup.

## Workload and equivalence

All real-audio tests use original A15_T510077 CH03, source seconds 2048–2184,
with the saved v1 hints. Input SHA-256:
`c1a3a8cebd1abb2bed869272017e230574efa5f8d18b819c7ad62cb170214c7b`.
The model contains 58 accepted components. On each platform separately, all
four single-worker runs produced identical float64 model hashes, identical
corrected float32 samples, and identical complete diagnostic records. All
twelve final model hashes from the Genus six-worker comparison also matched.
This does not assert bitwise equality between Windows and Linux.

These initial measurements are `model_window(..., defer_compact=True)` tests, not completed production
WAV renders. Timing excludes loading, writing, blending/compact union application,
checkpointing, normalization and publication. Model-equivalent throughput counts
64 new seconds per model, matching steady-state production anchor spacing, not
the overlapping 136-second model context. This one complex interval does not
establish general equivalence or an archive-wide speedup.

## Implementation

`research/profile_denoise_numba.py` exposes `fused_observations`, a single-thread
`numba.njit(fastmath=False)` loop using float64/complex128. It directly computes
weighted projections, avoiding full-length scaled-sample, conjugate and
demodulation temporaries. The original `observations()` at
`scripts/denoise_v2.py:70` is replaced only inside standalone experiment
processes, then restored. No production module was edited.

Earlier loaded-Genus profiling attributed 19.826/48.857 seconds to observations
including its callees. Conjugation time must not be added again to that total.
NumPy/SciPy already perform substantial work in compiled routines; reducing
array allocation and memory passes is the demonstrated opportunity.

Next candidates are fused oscillator/model-accumulation expressions in
`model_window`, `stationary_shifted_comb`, and `residual_refinement`. Their
individual benefit remains unmeasured. A wholesale FFT or native-language port
is not justified by the current profile. C/Cython or Rust/PyO3 could package a
proven kernel without runtime JIT, but are not inherently faster than Numba's
generated native loop.

## Environment and production boundaries

NumPy 2.5.4, SciPy 1.18.1, soundfile 0.14.0, Numba 0.68.0. Windows used its
existing environment. Linux used an isolated `uv run --with` overlay with those
exact versions; the qualified production environment still has no Numba
installed. Production was stopped for full-model tests. Frozen production code
identity was verified unchanged afterward; audio and checkpoints were untouched.

Before deployment, compare saved qualification/review intervals, beginning/end
contexts, quiet/bypass cases, shifted combs, saved noncomb tones and refinement
paths, including full rendered samples and acceptance decisions. Keep strict
arithmetic and single-thread kernels initially. A new qualified implementation
identity and explicit checkpoint/output migration are required; this is not a
scheduling-only change. Preserve completed and approval-bound audio.

## Reproduction

Windows: `uv run python research/profile_denoise_numba.py --output <new-json>`.

Linux single-model command:

```sh
/home/bfeist/.local/bin/uv run --no-project --python /home/bfeist/.local/share/apollo15-venv/bin/python --with numba==0.68.0 --with numpy==2.5.4 --with scipy==1.18.1 --with soundfile==0.14.0 /mnt/f/_repos/Apollo_15/research/profile_denoise_numba.py --output /home/bfeist/new-model-test.json
```

For concurrency, use the same environment prefixed by
`taskset -c 0,2,4,8,10,12`, script `research/profile_genus_workers.py`, and
arguments `--counts 6 --repeats 3 --backend numpy --output <new-json>`.
Repeat sequentially with `--backend numba`. Do not benchmark alongside production.

Official references: [Numba performance tips](https://numba.readthedocs.io/en/latest/user/performance-tips.html),
[Numba NumPy support](https://numba.readthedocs.io/en/stable/reference/numpysupported.html),
[Cython array access](https://docs.cython.org/en/latest/src/userguide/numpy_tutorial.html),
[PyO3](https://pyo3.rs/main/index.html).

## Production backend qualification and additional fusion

The additive `scripts/denoise_v2_numba.py` executes unchanged reference source in
a private namespace. The canonical `denoise_v2` module and frozen reference files
remain unchanged. Its final identity is
`apollo15-v2.16-numba-platform-kernels-v2`: strict, single-thread observations on
both hosts, plus a complex128 exponential kernel on Windows. Other NumPy calls,
real/scalar exponentials and the reference refinement module retain NumPy.

An isolated Windows ABBA full-model comparison measured observations-only at
9.255/9.749 seconds and observations plus exp at 7.572/7.635 seconds: a further
1.25x throughput improvement on that interval. Float64 models, corrected float32
samples and complete records matched exactly, as did all seven synthetic cases.
See `windows_oscillator_fullmodel_isolated.json`. Linux measured the same
candidate slower (about 18%), so Linux intentionally retains NumPy exponentials.
These timings concern the measured model interval rather than archive-wide
render, I/O, normalization or publication throughput. The initial oscillator
profile overlapped qualification and is retained only as supporting exactness
evidence; the isolated repeat supplies the Windows timing comparison.

`research/qualify_denoise_numba.py` compares complete diagnostic records and exact
float64 models/render samples and float32 outputs. Its seven synthetic cases
cover short context, silence, voice without comb evidence, a comb outage,
tracked residual refinement, shifted combs and saved noncomb lines. Six real
`corrected_chunks` renders reuse all four saved cluster probes and add the true
final source boundary and an arbitrary crop. They exercise compact low and
shifted-line union application as well as ordinary blending and saved hints.
The report binds source context/record/output hashes, reference and backend code,
numerical versions, backend policy and active features. Unit tests also cover
odd and strided observations, cancellation, private namespace isolation,
complex exp shape/stride preservation and real/scalar fallback.

`windows_broad_qualification_v2.json` passed all 13 cases for the earlier
observations-only identity; saved Windows probe outputs were bit-identical.
`windows_platform_kernels_qualification.json` is the final Windows qualification
run, with the platform policy enabled; only a report with `passed: true` is
complete. Linux is qualified independently under the same final backend hash.

`windows_additional_fusion_v2.json` rejects fused harmonic accumulation: despite
an approximately 7x kernel-only gain, rounding differed by up to 1.11e-16.
Its oscillator kernel-only gain motivated the subsequent full-model work.
`windows_additional_fusion.json` is an invalid exploratory report: the comparison
array was mutated during timing before exactness was recorded. It is retained
for provenance and superseded by the v2 report. `windows_broad_qualification.json`
is incomplete (`passed: false`) because its summary assumed every refinement row
contained `passes`; it is superseded by the v2 and final reports.

The oscillator reproduction script explicitly disables exp only in its isolated
private observations baseline because the final Windows backend now enables it.
It does not alter the canonical reference module or any production files.
