"""Full-model oscillator candidate measurement and exactness investigation."""
import os
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
             'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'

import argparse
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
import numpy as np
import soundfile as sf
import denoise_v2_numba as baseline
import denoise_v2_oscillator_candidate as candidate
from qualify_denoise_numba import difference, synthetic_cases
from render_denoise_v2 import gather_seeds, saved_seeds


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Output exists')
    # This is an isolated experiment process. The deployed Windows backend now
    # includes exp, so explicitly recover the observations-only private baseline
    # for reproducing the comparison. The canonical reference is never changed.
    baseline._reference.np = np
    base = Path('D:/Apollo_15_30-Track' if os.name == 'nt' else '/mnt/d/Apollo_15_30-Track')
    source = next((base/'orig_concatenated/A15_T510077').glob('*_CH3_*.wav'))
    a, b = 2048*8000, 2184*8000
    with sf.SoundFile(source) as stream:
        stream.seek(a)
        samples = stream.read(b-a, dtype='float64')
    hints = gather_seeds(saved_seeds(base/'denoised_v1/A15_T510077/CH03/cleanup.jsonl', a, b), a, b)
    baseline.warmup()
    candidate.warmup()
    report = dict(platform=platform.platform(), runs=[], synthetic=[], passed=False,
                  baseline_override='private namespace NumPy exp; observations-only',
                  backend_sha256=hashlib.sha256(Path(baseline.__file__).read_bytes()).hexdigest(),
                  code_sha256={str(Path(name)):hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                               for name in ('denoise_v2_oscillator_candidate.py', 'profile_denoise_oscillator.py')})
    expected = record = None
    args.output.parent.mkdir(parents=True, exist_ok=True)
    def save():
        args.output.write_text(json.dumps(report, indent=2)+'\n')
    for dsp in (baseline, candidate, candidate, baseline):
        tick = time.perf_counter()
        result, diagnostic = dsp.model_window(samples, hints, defer_compact=True)
        seconds = time.perf_counter()-tick
        if expected is None:
            expected, record = result, diagnostic
        row = dict(backend='observations_only' if dsp is baseline else 'observations_plus_exp',
                   seconds=seconds, model_difference=difference(expected, result),
                   records_equal=record == diagnostic, corrected_float32_difference=difference(
                       (samples-expected).astype('<f4'), (samples-result).astype('<f4')))
        report['runs'].append(row)
        save()
        print(json.dumps(row), flush=True)
    for name, x, seeds in synthetic_cases():
        first, ra = baseline.model_window(x, seeds, defer_compact=True)
        second, rb = candidate.model_window(x, seeds, defer_compact=True)
        row = dict(name=name, model_difference=difference(first, second), records_equal=ra == rb)
        report['synthetic'].append(row)
        save()
        print(json.dumps(row), flush=True)
    report['passed'] = all(v['model_difference']['exact'] and v['records_equal']
                           for v in report['runs']+report['synthetic'])
    save()


if __name__ == '__main__':
    main()
