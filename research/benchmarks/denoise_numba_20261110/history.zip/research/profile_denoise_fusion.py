"""Measure additional strict fusion candidates without changing either backend.

Kernel timings alone are not deployment evidence. An oscillator with different
rounding is disqualified even when its audio error is numerically small.
"""
import os
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'

import argparse
import hashlib
import json
from pathlib import Path
import platform
import time

import numba
import numpy as np


@numba.njit(fastmath=False, parallel=False)
def accumulation(model, gate, component_gate, coef, osc):
    for i in range(len(model)):
        value = coef.real*osc[i].real-coef.imag*osc[i].imag
        model[i] += (gate[i]*component_gate[i])*value


@numba.njit(fastmath=False, parallel=False)
def oscillator(phase, harmonic):
    result = np.empty(len(phase), dtype=np.complex128)
    for i in range(len(phase)):
        result[i] = np.exp((1j*harmonic)*phase[i])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Output exists')
    rng = np.random.default_rng(815)
    size = 136*8000
    phase = np.arange(size)/8000*2*np.pi*60+.001*rng.normal(size=size)
    osc = np.exp(1j*53*phase)
    gate, local, model = [rng.uniform(-1, 1, size=size) for _ in range(3)]
    coef = complex(.0013, -.0047)
    expected = model+gate*local*np.real(coef*osc)
    actual = model.copy()
    accumulation(actual, gate, local, coef, osc)
    candidate = oscillator(phase, 53)
    rows = []
    for name, a, b, original, fused in (
        ('harmonic_accumulation', expected, actual,
         lambda:model+gate*local*np.real(coef*osc),
         lambda:accumulation(actual, gate, local, coef, osc)),
        ('harmonic_oscillator', osc, candidate,
         lambda:np.exp(1j*53*phase), lambda:oscillator(phase, 53))):
        exact = bool(np.array_equal(a, b))
        peak_error = float(np.max(abs(a-b)))
        durations = [[], []]
        for _ in range(9):
            for index, operation in enumerate((original, fused)):
                tick = time.perf_counter()
                operation()
                durations[index].append(time.perf_counter()-tick)
        rows.append(dict(candidate=name, exact=exact,
                         peak_error=peak_error,
                         median_seconds=[float(np.median(v)) for v in durations],
                         adopted=False, reason='No measured whole-model benefit; keep the qualified backend minimal'
                         if exact else 'Nonidentical arithmetic disqualifies this candidate'))
    report = dict(platform=platform.platform(), numpy=np.__version__, numba=numba.__version__,
                  samples=size, fastmath=False, parallel=False, candidates=rows,
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
