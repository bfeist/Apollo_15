"""Isolated observation-kernel experiment; never edits production or checkpoints."""
import os
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
             'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'

import argparse
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
import numba
import numpy as np
import soundfile as sf
import denoise_v2 as dsp
from render_denoise_v2 import saved_seeds, gather_seeds


@numba.njit(fastmath=False)
def fused_observations(samples, oscillator, starts, window):
    result = np.empty(len(starts), dtype=np.complex128)
    for index in range(len(starts)):
        real, imag = 0., 0.
        start = starts[index]
        for offset in range(len(window)):
            sample = 2.*samples[start+offset]
            real += (sample*oscillator[start+offset].real)*window[offset]
            imag += (-sample*oscillator[start+offset].imag)*window[offset]
        result[index] = complex(real, imag)
    return result


def digest(value):
    return hashlib.sha256(value.tobytes()).hexdigest()


def difference(a, b):
    residual = a.astype('float64')-b.astype('float64')
    return dict(peak=float(np.max(abs(residual))),
                rms=float(np.sqrt(np.mean(residual**2))),
                exact=bool(np.array_equal(a, b)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Output already exists; preserve earlier experiments')
    base = Path('D:/Apollo_15_30-Track' if os.name == 'nt' else '/mnt/d/Apollo_15_30-Track')
    source = next((base/'orig_concatenated/A15_T510077').glob('*_CH3_*.wav'))
    start, end = 2048*8000, 2184*8000
    with sf.SoundFile(source) as stream:
        stream.seek(start)
        samples = stream.read(end-start, dtype='float64')
    hints = gather_seeds(saved_seeds(base/'denoised_v1/A15_T510077/CH03/cleanup.jsonl', start, end), start, end)
    # Compile with the exact dtypes/layout used in production, outside timing.
    tick = time.perf_counter()
    fused_observations(np.zeros(8000), np.ones(8000, dtype=np.complex128),
                       np.array([0, 2000, 4000]), np.ones(4000)/4000)
    compilation = time.perf_counter()-tick
    original = dsp.observations
    result = dict(platform=platform.platform(), python=sys.version, numpy=np.__version__,
                  numba=numba.__version__, source=str(source), source_interval=[start,end],
                  input_sha256=digest(samples), hints=hints, compilation_seconds=compilation,
                  fastmath=False, parallel=False, runs=[])
    expected_model = expected_record = None
    try:
        for backend in ('numpy', 'numba', 'numba', 'numpy'):
            dsp.observations = original if backend == 'numpy' else fused_observations
            tick = time.perf_counter()
            model, record = dsp.model_window(samples, hints, defer_compact=True)
            elapsed = time.perf_counter()-tick
            if expected_model is None:
                expected_model, expected_record = model, record
            row = dict(backend=backend, seconds=elapsed, model_sha256=digest(model),
                       record_equal=record == expected_record,
                       model_difference=difference(expected_model, model),
                       corrected_float32_difference=difference((samples-expected_model).astype('float32'),
                                                               (samples-model).astype('float32')),
                       components=len(record['components']))
            result['runs'].append(row)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(result, indent=2))
            print(json.dumps(row), flush=True)
    finally:
        dsp.observations = original


if __name__ == '__main__':
    main()
